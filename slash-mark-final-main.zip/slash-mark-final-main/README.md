# slash-mark-final
   
    
    
ADVANCED Project:
    Final Task : User Authentication System

  Description : The user authentication system is a widely used software across every industry. This advanced-level cyber security project adds weight to your cyber security profile and intrigues potential recruiters.

